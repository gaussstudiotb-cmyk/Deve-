package com.deve.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Reconnaissance vocale + synthèse vocale. À utiliser depuis le thread principal. */
class VoiceEngine(
    private val ctx: Context,
    private val onRms: (Float) -> Unit,
    private val onResult: (String) -> Unit,
    private val onError: (Int) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var onSpeechDone: (() -> Unit)? = null
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.FRENCH
                ttsReady = true
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { finishSpeech() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { finishSpeech() } }
        })
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError(-1)
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                onRms(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { this@VoiceEngine.onError(error) }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) this@VoiceEngine.onError(SpeechRecognizer.ERROR_NO_MATCH)
                else onResult(t)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        r.startListening(intent)
    }

    fun stopListening() { recognizer?.stopListening() }

    fun speak(text: String, done: () -> Unit) {
        onSpeechDone = done
        if (!ttsReady || text.isBlank()) {
            main.post { finishSpeech() }
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "deve")
    }

    fun stopSpeaking() {
        onSpeechDone = null
        tts.stop()
    }

    private fun finishSpeech() {
        val d = onSpeechDone
        onSpeechDone = null
        d?.invoke()
    }

    fun destroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
    }
}
