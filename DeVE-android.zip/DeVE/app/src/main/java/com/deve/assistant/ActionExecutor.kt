package com.deve.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DeVEAction(val type: String, val target: String = "")
data class ActionResult(val error: String? = null, val info: String? = null)

class ActionExecutor(private val ctx: Context) {

    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null

    fun execute(a: DeVEAction): ActionResult = try {
        when (a.type) {
            "call" -> call(a.target)
            "launch_app" -> launchApp(a.target)
            "close_app" -> closeApp()
            "record_start" -> startRecording()
            "record_stop" -> stopRecording()
            else -> ActionResult()
        }
    } catch (e: Exception) {
        ActionResult(error = "Je n'ai pas réussi : ${e.message ?: "erreur inconnue"}")
    }

    // ---------- Appels ----------

    private fun call(target: String): ActionResult {
        if (!granted(Manifest.permission.CALL_PHONE))
            return ActionResult(error = "Autorise d'abord les appels pour DeVE dans les réglages.")
        val number = if (Regex("^[+0-9 ().-]{3,}$").matches(target.trim())) target.trim()
        else findNumber(target) ?: return ActionResult(error = "Je ne trouve pas $target dans tes contacts.")
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return ActionResult()
    }

    private fun findNumber(name: String): String? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val wanted = norm(name)
        var first: String? = null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (norm(n) == wanted) return num
                if (first == null) first = num
            }
        }
        return first
    }

    // ---------- Applications ----------

    private fun launchApp(name: String): ActionResult {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val wanted = norm(name)
        val match = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == wanted }
            ?: apps.firstOrNull {
                val l = norm(it.loadLabel(pm).toString())
                wanted.isNotEmpty() && (l.contains(wanted) || wanted.contains(l))
            }
            ?: return ActionResult(error = "Je ne trouve pas l'application $name.")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ActionResult(error = "Impossible d'ouvrir $name.")
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult()
    }

    private fun closeApp(): ActionResult {
        val service = DeVEAccessibilityService.instance
        if (service == null) {
            ctx.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return ActionResult(error = "Active le service DeVE dans l'accessibilité pour que je puisse quitter les applis.")
        }
        service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
        return ActionResult()
    }

    // ---------- Enregistrement audio ----------

    private fun startRecording(): ActionResult {
        if (!granted(Manifest.permission.RECORD_AUDIO))
            return ActionResult(error = "Autorise le micro pour que je puisse enregistrer.")
        if (recorder != null) return ActionResult(info = "Je enregistre déjà.")
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "deve_$stamp.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioEncodingBitRate(128_000)
        r.setAudioSamplingRate(44_100)
        r.setOutputFile(file.absolutePath)
        r.prepare()
        r.start()
        recorder = r
        recordingFile = file
        return ActionResult()
    }

    private fun stopRecording(): ActionResult {
        val r = recorder ?: return ActionResult(info = "Aucun enregistrement en cours.")
        try { r.stop() } catch (_: RuntimeException) { }
        r.release()
        recorder = null
        val f = recordingFile
        recordingFile = null
        return ActionResult(info = "Enregistrement sauvegardé : ${f?.name ?: ""}")
    }

    fun release() {
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
    }

    // ---------- Utilitaires ----------

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace(Regex("[^a-z0-9]"), "")
}
