package com.deve.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class DeVEReply(val raw: String, val speech: String, val action: DeVEAction)

object ClaudeClient {

    private const val API_URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-5-5"

    private val SYSTEM = """
Tu es DeVE, un assistant vocal sur le téléphone Android de l'utilisateur.
Tu parles français, de façon brève et chaleureuse : une phrase courte, car elle est dite à voix haute (pas de markdown, pas d'emoji).
Tu réponds TOUJOURS et UNIQUEMENT avec un objet JSON, sans aucun texte autour :
{"speech":"ce que tu dis à voix haute","action":{"type":"...","target":"..."}}
Types d'action possibles :
- none : simple conversation ou question
- call : appeler quelqu'un (target = nom du contact ou numéro)
- launch_app : ouvrir une application (target = nom de l'application)
- close_app : quitter l'application en cours et revenir à l'accueil
- record_start : démarrer un enregistrement audio
- record_stop : arrêter l'enregistrement
N'invente jamais de numéro de téléphone. Si la demande est ambiguë, pose une question courte avec l'action none.
""".trimIndent()

    suspend fun ask(
        apiKey: String,
        history: List<Pair<String, String>>,
        userText: String
    ): DeVEReply = withContext(Dispatchers.IO) {
        val msgs = JSONArray()
        history.takeLast(10).forEach { (role, content) ->
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))

        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", msgs)

        val conn = (URL(API_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", apiKey)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("API $code")

        val raw = JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
        parse(raw)
    }

    private fun parse(raw: String): DeVEReply {
        return try {
            val json = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
            val act = json.optJSONObject("action")
            DeVEReply(
                raw = raw,
                speech = json.optString("speech", ""),
                action = DeVEAction(
                    type = act?.optString("type", "none") ?: "none",
                    target = act?.optString("target", "") ?: ""
                )
            )
        } catch (e: Exception) {
            DeVEReply(raw, raw.take(200), DeVEAction("none"))
        }
    }
}
