package com.deve.assistant

import android.app.Application
import android.content.Context
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING, RECORDING }

class DeVEViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("deve", Context.MODE_PRIVATE)
    private val executor = ActionExecutor(app)
    private val history = mutableListOf<Pair<String, String>>()

    var phase by mutableStateOf(Phase.IDLE)
        private set
    var caption by mutableStateOf("Touche l'orbe pour parler à DeVE")
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var apiKey by mutableStateOf(prefs.getString("api_key", "") ?: "")
        private set

    private val voice = VoiceEngine(
        app,
        onRms = { level = it },
        onResult = { onHeard(it) },
        onError = { onVoiceError(it) }
    )

    fun saveKey(key: String) {
        apiKey = key.trim()
        prefs.edit().putString("api_key", apiKey).apply()
    }

    fun onOrbTap() {
        when (phase) {
            Phase.IDLE -> startListening()
            Phase.LISTENING -> voice.stopListening()
            Phase.SPEAKING -> {
                voice.stopSpeaking()
                phase = Phase.IDLE
                caption = "Touche l'orbe pour parler à DeVE"
            }
            Phase.RECORDING -> stopRecording()
            Phase.THINKING -> Unit
        }
    }

    private fun startListening() {
        if (apiKey.isBlank()) {
            caption = "Ajoute ta clé API dans Réglages."
            return
        }
        phase = Phase.LISTENING
        caption = "Je t'écoute…"
        voice.startListening()
    }

    private fun onHeard(text: String) {
        level = 0f
        caption = "« $text »"
        phase = Phase.THINKING
        viewModelScope.launch {
            try {
                val reply = ClaudeClient.ask(apiKey, history.toList(), text)
                history += "user" to text
                history += "assistant" to reply.raw

                if (reply.action.type == "record_start") {
                    // On parle d'abord, puis on lance l'enregistrement (pour ne pas enregistrer la voix de DeVE).
                    phase = Phase.SPEAKING
                    caption = reply.speech
                    voice.speak(reply.speech) {
                        val r = executor.execute(reply.action)
                        if (r.error != null) {
                            phase = Phase.IDLE
                            caption = r.error
                        } else {
                            phase = Phase.RECORDING
                            caption = "Enregistrement en cours…\nTouche l'orbe pour arrêter"
                        }
                    }
                } else {
                    val r = executor.execute(reply.action)
                    val say = r.error ?: r.info ?: reply.speech
                    phase = Phase.SPEAKING
                    caption = say
                    voice.speak(say) { phase = Phase.IDLE }
                }
            } catch (e: Exception) {
                phase = Phase.IDLE
                caption = when {
                    e.message?.contains("401") == true -> "Clé API refusée. Vérifie-la dans Réglages."
                    else -> "Impossible de joindre l'IA. Vérifie ta connexion."
                }
            }
        }
    }

    private fun stopRecording() {
        val r = executor.execute(DeVEAction("record_stop"))
        val say = r.error ?: r.info ?: "Enregistrement terminé."
        phase = Phase.SPEAKING
        caption = say
        voice.speak("Enregistrement terminé.") { phase = Phase.IDLE }
    }

    private fun onVoiceError(code: Int) {
        level = 0f
        phase = Phase.IDLE
        caption = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Je n'ai rien entendu. Touche l'orbe pour réessayer."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Autorise le micro pour DeVE."
            -1 -> "La reconnaissance vocale n'est pas disponible sur ce téléphone."
            else -> "Erreur vocale ($code). Réessaie."
        }
    }

    override fun onCleared() {
        voice.destroy()
        executor.release()
    }
}
