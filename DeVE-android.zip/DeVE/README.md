# DeVE — assistant vocal Android

1. Ouvre le dossier dans Android Studio (Hedgehog ou plus récent), laisse la synchro Gradle se faire.
2. Branche ton téléphone (débogage USB) et lance l'appli.
3. Accepte micro / appels / contacts, colle ta clé API Anthropic dans « Réglages ».
4. Pour « quitte l'appli » : Réglages Android > Accessibilité > DeVE > activer.

Exemples : « Appelle Maman », « Ouvre WhatsApp », « Lance un enregistrement », « Quitte l'appli ».
